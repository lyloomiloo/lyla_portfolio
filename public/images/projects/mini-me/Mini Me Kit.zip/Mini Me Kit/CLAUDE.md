# Mini Me — making it look like someone

This is a desktop pet: a small character that floats on top of the screen,
wanders about, naps, and can put on an animal onesie. It ships with one
plain starter character. The job is usually to turn that starter into a
specific person, from photos.

## Look at your work

You are drawing. You cannot do this blind — every mistake in this codebase
is a visual one, and none of them show up as an error.

```
npm run look                  every outfit, side by side -> preview.png
npm run look -- --pose drag   every outfit in a pose
npm run look -- --animal      the animal onesie
npm run look -- --who alex    one character
```

Then **read preview.png**. The thin outline in each panel is the real window
edge, so anything crossing it will be clipped on screen.

Poses: `drag happy dance wave surprised sleep stretch walk`

Expect several rounds. Draw, render, look, adjust. Shapes that seem fine as
path data are regularly wrong on screen — hair that reads as a helmet, a
top narrower than the torso so bare skin shows at the sides, a hat brim the
same colour as the crown so it disappears. You will only catch these by
looking.

## The files

```
main.js            the window, dragging, tray menu, saved settings
preload.js         the bridge between the window and the drawing
renderer/
  you.html         THE CHARACTER. this is what you edit
  style.css        colours at the top, then one block per mood
  pet.js           behaviour: idle loop, reactions, outfit switching
  sound.js         all sounds, synthesised — there are no audio files
tools/render.js    the preview renderer above
```

You will almost always work in `you.html` and the top of `style.css`.
`pet.js`, `sound.js`, `main.js` and `preload.js` rarely need touching.

## The drawing grid

The character is one inline SVG on a 200 × 220 grid. Fixed landmarks:

| | |
|---|---|
| head centre | (100, 76), radius 45 |
| neck | x 91–109, y 108–124 |
| shoulders / chest | y 120–150, x 74–126 |
| arms | x 59–73 and 127–141, y 126–170 |
| hands | (66, 170) and (134, 170) |
| hips | y 144–172 |
| legs | y 148–200 |
| floor shadow | y 209 |

**Keep the body geometry.** The animations are tuned to these numbers. Change
the head, hair and clothes freely; leave the limb positions alone unless you
intend to retune the animation.

**Never rename an id.** `#legL #legR #armL #armR #head #eyes #eyesHappy
#mouth #face #fringe #hairBack #shadow #hearts #cathat #tail #poof #zzz`
all have animations hanging off them in `style.css`. A renamed part stops
moving, silently.

## How outfits work

Every clothing shape carries `data-fit="<outfit id>"`. Only the chosen
outfit's parts are drawn; `pet.js` reads the wardrobe out of the DOM, so
there is no list of outfits to keep in sync inside the renderer.

Each outfit needs parts in four places, or it will look broken:

1. `#legL` and `#legR` — trousers or bare legs, **plus shoes**
2. `#hips` — a shape filling the gap between the legs
3. `#armL` and `#armR` — sleeves, if the top has them (they sit *inside* the
   arm groups so they swing when walking)
4. `#tops` — the garment itself
5. `#headwear` — optional: hats, clips, glasses

To add an outfit:

- add its shapes with `data-fit="beach"` in those groups
- add its colours as classes near the top of `style.css`
- add `'beach'` to that character's list in `OUTFITS` in `main.js`

## Adding a character

1. Copy `renderer/you.html` to `renderer/alex.html`.
2. Set `data-name="alex"` on the `<svg>` — this is the name in the greeting,
   "hola, I'm mini alex!". `data-greeting` is the second line.
   `data-critter="dog"` makes the onesie woof instead of meow.
3. Redraw the head and the wardrobe. Keep every id.
4. In `main.js`, add `['alex', 'Mini Alex']` to `CHARACTERS` and the outfit
   ids to `OUTFITS`.
5. If they need their own skin or hair colour, add
   `body.alex { --skin: ...; --hair: ...; }` to `style.css` and put
   `class="alex"` on the `<body>` of their file.

## Drawing a face that looks like someone

Distance matters more than detail. The character is about 170 pixels tall on
screen, so fine features turn to mush. What actually reads:

- **hair silhouette** — by far the strongest signal. Build it as one
  continuous shape, not several pieces that happen to sit near each other,
  or it falls apart into blobs
- **hair colour and a parting**, if there is one — two tones, the front a
  touch lighter than the back
- **facial hair**, as a band hugging the jaw. Err thin; a thick beard turns
  the whole lower face into one dark mass
- **glasses, hats, a distinctive clip**
- **clothing colour blocks**, not patterns. For a print, use a repeating
  `<pattern>` with irregular placement, kept low-contrast

Things that will not read: eye shape, nose shape, small logos, freckles.

## Traps worth knowing

- **A CSS `transform` replaces an SVG `transform` attribute.** If a shape is
  positioned with `transform="translate(40,60)"` and an animation sets
  `transform:` on the same element, the position is wiped and the shape
  jumps to the origin. Put the position on a wrapper group and animate the
  child.
- **`transform-box: fill-box`** on anything you rotate or scale in place.
  Without it the origin is the whole viewBox and the part flies off.
- **Draw order is paint order.** Skin drawn after trousers paints over them.
  If bare body shows through clothing, this is why.
- **Tops must be at least as wide as the torso** (74–126) or skin shows at
  the sides.
- **Two blacks side by side merge.** Give adjacent dark garments slightly
  different values, or a lighter sole / outline, so the silhouette survives.

## Running it

```
npm install     # once, pulls Electron
npm start
```

Right-click the character for the menu. Settings are saved to
`app.getPath('userData')/settings.json` — delete that folder to see the
introduction again.

To hand it to someone as an app: `npm run package:mac` or
`npm run package:win`. Both are unsigned, so first open needs
right-click → Open on a Mac, or "More info" → "Run anyway" on Windows.
