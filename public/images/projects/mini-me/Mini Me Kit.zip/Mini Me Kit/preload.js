// The only bridge between the pet drawing and the window controls.
// Nothing else from Electron is exposed, which keeps things safe and simple.

const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('pet', {
  setInteractive: (on) => ipcRenderer.send('pet:interactive', on),
  dragStart: () => ipcRenderer.send('pet:drag-start'),
  dragEnd: () => ipcRenderer.send('pet:drag-end'),
  step: (dx) => ipcRenderer.send('pet:step', dx),
  menu: () => ipcRenderer.send('pet:menu'),
  setCat: (on) => ipcRenderer.send('pet:cat-changed', on),
  introDone: () => ipcRenderer.send('pet:intro-done'),
  onEdge:   (fn) => ipcRenderer.on('pet:hit-edge', fn),
  onShaken: (fn) => ipcRenderer.on('pet:shaken', fn),
  onMute:   (fn) => ipcRenderer.on('pet:mute', fn),
  onCalm:   (fn) => ipcRenderer.on('pet:calm', fn),
  onCat:    (fn) => ipcRenderer.on('pet:cat', fn),
  onWear:   (fn) => ipcRenderer.on('pet:wear', fn),
  onIntro:  (fn) => ipcRenderer.on('pet:intro', fn),
  onCursor: (fn) => ipcRenderer.on('pet:cursor', fn),
  onMusic:  (fn) => ipcRenderer.on('pet:music', fn),
  onTempo:  (fn) => ipcRenderer.on('pet:tempo', fn),
  onMusicNote: (fn) => ipcRenderer.on('pet:music-note', fn),
  onDo:     (fn) => ipcRenderer.on('pet:do', fn)
});
