// The "window" part of the pet: a small, see-through, always-on-top box
// that floats above your other apps. The drawing happens in renderer/.

const { app, BrowserWindow, ipcMain, screen, Menu, Tray, nativeImage } = require('electron');
const path = require('path');
const fs = require('fs');
const { exec } = require('child_process');

app.commandLine.appendSwitch('autoplay-policy', 'no-user-gesture-required');

// A strip above the character, so the speech bubble never lands on their face.
const BUBBLE_ROOM = 46;

// While they introduce themselves the window grows, so the greeting fits.
const INTRO_ROOM  = 84;
const INTRO_WIDTH = 330;

// The shape is the same at every size (the drawing is 200 x 220).
// Two characters, each with their own wardrobe. They pick an outfit for
// themselves; there is no wardrobe list to choose from.
// ADD YOUR CHARACTER HERE.
// The id must match the file name in renderer/ (so 'you' -> renderer/you.html)
// and the outfit ids must match the data-fit values in that file.
const CHARACTERS = [['you', 'Mini You']];

const OUTFITS = {
  you: ['tee', 'hoodie', 'dress']
};

// Dance tempo. Spotify's local scripting does not expose a track's bpm,
// so this is a setting rather than something detected. One beat is
// 60 / bpm seconds, which is what the drawing animates against.
const TEMPOS = [['slow', 'Slow (75)', 75], ['normal', 'Normal (110)', 110],
                ['fast', 'Fast (145)', 145]];

const SIZES = {
  tiny:   [130, 143],
  small:  [170, 187],
  medium: [220, 242],
  large:  [280, 308]
};

let win = null;
let tray = null;
let dragTimer = null;

// --- saved settings -------------------------------------------------------

const settingsFile = path.join(app.getPath('userData'), 'settings.json');
const settings = Object.assign(
  { size: 'small', calm: false, muted: false, cat: false, music: false, tempo: 'normal',
    who: 'you', outfit: 'tee', seenIntro: false },
  readSettings()
);

// A saved character that no longer exists (renamed, removed) must not
// take the app down on launch.
function validateSettings() {
  if (!OUTFITS[settings.who]) settings.who = CHARACTERS[0][0];
  if (!OUTFITS[settings.who].includes(settings.outfit)) {
    settings.outfit = OUTFITS[settings.who][0];
  }
  if (!SIZES[settings.size]) settings.size = 'small';
  if (!TEMPOS.some(t => t[0] === settings.tempo)) settings.tempo = 'normal';
}

function readSettings() {
  try { return JSON.parse(fs.readFileSync(settingsFile, 'utf8')); }
  catch { return {}; }
}

validateSettings();

function saveSettings() {
  try { fs.writeFileSync(settingsFile, JSON.stringify(settings, null, 2)); }
  catch { /* not being able to save a preference is not worth crashing over */ }
}

// --- window ---------------------------------------------------------------

function createWindow() {
  const [charW, charH] = SIZES[settings.size];
  const w = settings.seenIntro ? charW : Math.max(charW, INTRO_WIDTH);
  const h = charH + (settings.seenIntro ? BUBBLE_ROOM : INTRO_ROOM);
  const area = screen.getPrimaryDisplay().workArea;

  win = new BrowserWindow({
    width: w,
    height: h,
    x: Math.round(area.x + area.width - w - 60),
    y: Math.round(area.y + area.height - h - 10),
    frame: false,          // no title bar
    transparent: true,     // see-through background
    hasShadow: false,
    resizable: false,
    skipTaskbar: true,
    fullscreenable: false,
    alwaysOnTop: true,
    webPreferences: { preload: path.join(__dirname, 'preload.js') }
  });

  // Float above almost everything, including full-screen apps.
  win.setAlwaysOnTop(true, 'screen-saver');
  win.setVisibleOnAllWorkspaces(true, { visibleOnFullScreen: true });

  // Clicks pass straight through the empty corners of the box.
  // The pet turns this off for itself when your cursor is over it.
  win.setIgnoreMouseEvents(true, { forward: true });

  win.loadFile(path.join(__dirname, 'renderer', settings.who + '.html'));
  win.webContents.on('did-finish-load', () => {
    tell('pet:calm', settings.calm);
    tell('pet:mute', settings.muted);
    tell('pet:cat', settings.cat);
    tell('pet:wear', settings.outfit);
    tell('pet:tempo', bpm());
    if (musicPlaying) tell('pet:music', true);
    if (!settings.seenIntro) tell('pet:intro');
  });
}

function tell(channel, payload) {
  if (win && !win.isDestroyed()) win.webContents.send(channel, payload);
}

function recentre() {
  if (!win) return;
  const b = win.getBounds();
  const area = screen.getPrimaryDisplay().workArea;
  win.setPosition(
    Math.round(area.x + area.width / 2 - b.width / 2),
    Math.round(area.y + area.height - b.height - 10)
  );
}

// Resizing keeps the feet where they were, so nothing jumps about.
function setSize(name) {
  if (!win || !SIZES[name]) return;
  const [w, charH] = SIZES[name];
  const h = charH + BUBBLE_ROOM;
  const b = win.getBounds();
  settings.size = name;
  saveSettings();
  win.setBounds({
    width: w,
    height: h,
    x: Math.round(b.x + (b.width - w) / 2),
    y: Math.round(b.y + (b.height - h))
  });
  refreshMenu();
}

// A different outfit from the one they have on now.
function rollOutfit() {
  const wardrobe = OUTFITS[settings.who] || OUTFITS[CHARACTERS[0][0]];
  const pool = wardrobe.filter(id => id !== settings.outfit);
  return (pool.length ? pool : wardrobe)[Math.floor(Math.random() * (pool.length || wardrobe.length))];
}

// Swapping character loads the other drawing, so the window reloads and
// they introduce themselves.
function setCharacter(name) {
  if (!win || settings.who === name) return;
  settings.who = name;
  settings.outfit = rollOutfit();
  settings.seenIntro = false;
  saveSettings();

  const [charW, charH] = SIZES[settings.size];
  const w = Math.max(charW, INTRO_WIDTH);
  const h = charH + INTRO_ROOM;
  const b = win.getBounds();
  win.setBounds({
    width: w,
    height: h,
    x: Math.round(b.x + (b.width - w) / 2),
    y: Math.round(b.y + (b.height - h))
  });
  win.loadFile(path.join(__dirname, 'renderer', name + '.html'));
  refreshMenu();
}

function changeOutfit() {
  settings.outfit = rollOutfit();
  saveSettings();
  tell('pet:wear', settings.outfit);
}

// Put the window back to its normal size once the greeting is over.
function endIntro() {
  if (!win) return;
  settings.seenIntro = true;
  saveSettings();

  const [w, charH] = SIZES[settings.size];
  const h = charH + BUBBLE_ROOM;
  const b = win.getBounds();
  win.setBounds({
    width: w,
    height: h,
    x: Math.round(b.x + (b.width - w) / 2),
    y: Math.round(b.y + (b.height - h))
  }, true);
}

function playIntro() {
  if (!win) return;
  const [charW, charH] = SIZES[settings.size];
  const b = win.getBounds();
  const w = Math.max(charW, INTRO_WIDTH);
  const h = charH + INTRO_ROOM;
  win.setBounds({
    width: w,
    height: h,
    x: Math.round(b.x + (b.width - w) / 2),
    y: Math.round(b.y + (b.height - h))
  }, true);
  tell('pet:intro');
}

function toggleHidden() {
  if (!win) return;
  if (win.isVisible()) win.hide(); else win.show();
  refreshMenu();
}

// --- the menu (same one for the menu bar and for right-clicking the pet) ---

function buildMenu() {
  const hidden = !win || !win.isVisible();

  return Menu.buildFromTemplate([
    { label: hidden ? 'Show' : 'Hide', click: toggleHidden },
    { type: 'separator' },
    { label: 'Say hi', enabled: !hidden, click: () => tell('pet:do', 'wave') },
    { label: 'Dance',  enabled: !hidden, click: () => tell('pet:do', 'dance') },
    { label: 'Nap',    enabled: !hidden, click: () => tell('pet:do', 'sleep') },
    {
      label: 'Animal form',
      type: 'checkbox', checked: settings.cat, enabled: !hidden,
      toolTip: 'A full animal onesie',
      click: (item) => { settings.cat = item.checked; saveSettings(); tell('pet:cat', settings.cat); }
    },
    { type: 'separator' },
    {
      label: 'Calm mode', type: 'checkbox', checked: settings.calm,
      toolTip: 'Stays put and stays quiet',
      click: (item) => { settings.calm = item.checked; saveSettings(); tell('pet:calm', settings.calm); }
    },
    {
      label: 'Dance to music', type: 'checkbox', checked: settings.music,
      toolTip: 'Dances while Spotify or Music is playing (asks permission once)',
      click: (item) => { settings.music = item.checked; saveSettings(); watchMusic(settings.music, true); }
    },
    {
      label: 'Dance speed',
      enabled: !hidden,
      submenu: TEMPOS.map(([id, label]) => ({
        label, type: 'radio', checked: settings.tempo === id,
        click: () => { settings.tempo = id; saveSettings(); tell('pet:tempo', bpm()); }
      }))
    },
    {
      label: 'Mute sounds', type: 'checkbox', checked: settings.muted,
      click: (item) => { settings.muted = item.checked; saveSettings(); tell('pet:mute', settings.muted); }
    },
    {
      label: 'Character',
      enabled: !hidden,
      submenu: CHARACTERS.map(([id, label]) => ({
        label, type: 'radio', checked: settings.who === id,
        click: () => setCharacter(id)
      }))
    },
    { label: 'Surprise me',    enabled: !hidden, click: changeOutfit },
    { label: 'Introduce again', enabled: !hidden, click: playIntro },
    {
      label: 'Size',
      submenu: Object.keys(SIZES).map(name => ({
        label: name[0].toUpperCase() + name.slice(1),
        type: 'radio',
        checked: settings.size === name,
        click: () => setSize(name)
      }))
    },
    { label: 'Bring to centre', enabled: !hidden, click: recentre },
    { type: 'separator' },
    { label: 'Quit', accelerator: 'Command+Q', click: () => app.quit() }
  ]);
}

function refreshMenu() {
  if (tray) tray.setContextMenu(buildMenu());
}

function createTray() {
  tray = new Tray(nativeImage.createEmpty());
  tray.setTitle('◕');
  tray.setToolTip('Mini Me');
  refreshMenu();
}

// --- watching your cursor --------------------------------------------------
// The OS hands any app the pointer position, so this needs no permission.
// It is what lets the eyes follow you, and lets the pet notice when you
// have wandered off and when you come back.

let gazeTimer = null;
let lastPoint = null;
let lastMoved = Date.now();

function watchCursor() {
  clearInterval(gazeTimer);
  gazeTimer = setInterval(() => {
    if (!win || win.isDestroyed() || !win.isVisible() || dragTimer) return;

    const p = screen.getCursorScreenPoint();
    const b = win.getBounds();

    if (!lastPoint || Math.abs(p.x - lastPoint.x) > 2 || Math.abs(p.y - lastPoint.y) > 2) {
      lastPoint = p;
      lastMoved = Date.now();
    }

    // roughly where the head is inside the window
    const hx = b.x + b.width / 2;
    const hy = b.y + BUBBLE_ROOM + (b.height - BUBBLE_ROOM) * 0.22;
    const away = Math.hypot(p.x - hx, p.y - hy);

    tell('pet:cursor', {
      dx: Math.max(-1, Math.min(1, (p.x - hx) / 340)),
      dy: Math.max(-1, Math.min(1, (p.y - hy) / 280)),
      near: away < 150,
      idleFor: Date.now() - lastMoved
    });
  }, 200);
}

// --- watching what is playing ----------------------------------------------
// Asking Spotify what it is doing needs the one-time "control Spotify"
// prompt, so this is off until you switch it on. pgrep is used first so a
// closed Spotify is never launched just to be asked.

let musicTimer = null;
let musicPlaying = false;

function bpm() {
  return (TEMPOS.find(t => t[0] === settings.tempo) || TEMPOS[1])[2];
}

function tellMusic(on) {
  if (on === musicPlaying) return;
  musicPlaying = on;
  tell('pet:music', on);
}

// Reports one of: playing | paused | closed | denied
function askPlayer(appName, next) {
  exec(`pgrep -x ${appName}`, (notRunning) => {
    if (notRunning) return next('closed');
    exec(`osascript -e 'tell application "${appName}" to player state as string'`,
      (err, out, stderr) => {
        if (err) {
          // macOS refuses the question until you allow it, once, in the prompt
          const refused = /not authori[sz]ed|-1743|assistive access/i.test(String(stderr));
          return next(refused ? 'denied' : 'closed');
        }
        next(out.trim() === 'playing' ? 'playing' : 'paused');
      });
  });
}

// `announce` is set when you have just switched this on, so the pet can
// say what it found instead of silently doing nothing.
function checkMusic(announce) {
  const done = (state) => {
    tellMusic(state === 'playing');
    if (announce) tell('pet:music-note', state);
  };
  askPlayer('Spotify', (state) => {
    if (state === 'playing' || state === 'denied') return done(state);
    askPlayer('Music', (second) => done(second === 'closed' ? state : second));
  });
}

function watchMusic(on, announce) {
  clearInterval(musicTimer);
  musicTimer = null;
  tellMusic(false);
  if (!on) return;
  checkMusic(announce);
  musicTimer = setInterval(() => checkMusic(false), 5000);
}

// --- messages from the pet -------------------------------------------------

// Let the pet receive clicks only while the cursor is over its body.
ipcMain.on('pet:interactive', (_e, on) => {
  if (win) win.setIgnoreMouseEvents(!on, { forward: true });
});

// The pet can also change form by itself, so keep the menu's tick in step.
ipcMain.on('pet:intro-done', endIntro);

ipcMain.on('pet:cat-changed', (_e, on) => {
  settings.cat = on;
  saveSettings();
  refreshMenu();
});

// Right-clicking the pet opens the same menu, right where the cursor is.
ipcMain.on('pet:menu', () => {
  if (win) buildMenu().popup({ window: win });
});

// Dragging: follow the real cursor, so the pet never slips out from under it.
ipcMain.on('pet:drag-start', () => {
  if (!win || dragTimer) return;
  const start = screen.getCursorScreenPoint();
  const [wx, wy] = win.getPosition();
  const offsetX = start.x - wx;
  const offsetY = start.y - wy;

  let lastX = start.x;
  let dir = 0;
  let flips = 0;

  dragTimer = setInterval(() => {
    if (!win) return;
    const p = screen.getCursorScreenPoint();
    win.setPosition(p.x - offsetX, p.y - offsetY);

    // Counting direction changes tells us the pet is being shaken about.
    const moved = p.x - lastX;
    if (Math.abs(moved) > 6) {
      const nextDir = Math.sign(moved);
      if (dir && nextDir !== dir) flips++;
      dir = nextDir;
      lastX = p.x;
    }
    if (flips >= 6) {
      flips = 0;
      tell('pet:shaken');
    }
  }, 16);
});

ipcMain.on('pet:drag-end', () => {
  clearInterval(dragTimer);
  dragTimer = null;
});

// Walking: the pet asks to shift a few pixels sideways.
ipcMain.on('pet:step', (_e, dx) => {
  if (!win) return;
  const area = screen.getPrimaryDisplay().workArea;
  const [x, y] = win.getPosition();
  const minX = area.x;
  const maxX = area.x + area.width - win.getBounds().width;
  const next = Math.min(maxX, Math.max(minX, x + dx));
  win.setPosition(Math.round(next), y);
  if (next === minX || next === maxX) tell('pet:hit-edge');
});

// --- startup ---------------------------------------------------------------

app.whenReady().then(() => {
  if (process.platform === 'darwin' && app.dock) app.dock.hide();
  settings.outfit = rollOutfit();
  saveSettings();
  createWindow();
  createTray();
  watchCursor();
  watchMusic(settings.music);
  win.on('show', refreshMenu);
  win.on('hide', refreshMenu);
});

app.on('window-all-closed', () => app.quit());
