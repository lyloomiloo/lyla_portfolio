// Little sounds, made from scratch with the browser's audio engine.
// No sound files to download — every beep is generated as it plays.

const ctx = new AudioContext();
let muted = false;

function setMuted(on) { muted = on; }

// One short note. `slide` bends the pitch (2 = an octave up, 0.5 = down).
function blip(freq, { dur = 0.13, type = 'sine', vol = 0.05, slide = 0, delay = 0 } = {}) {
  if (muted) return;
  const t = ctx.currentTime + delay;
  const osc = ctx.createOscillator();
  const gain = ctx.createGain();

  osc.type = type;
  osc.frequency.setValueAtTime(freq, t);
  if (slide) osc.frequency.exponentialRampToValueAtTime(freq * slide, t + dur);

  gain.gain.setValueAtTime(0.0001, t);
  gain.gain.exponentialRampToValueAtTime(vol, t + 0.015);
  gain.gain.exponentialRampToValueAtTime(0.0001, t + dur);

  osc.connect(gain).connect(ctx.destination);
  osc.start(t);
  osc.stop(t + dur + 0.03);
}

// Soft breathy noise, used for the yawn and the snore.
function breath({ dur = 0.5, vol = 0.05, freq = 500, delay = 0 } = {}) {
  if (muted) return;
  const t = ctx.currentTime + delay;
  const frames = Math.floor(ctx.sampleRate * dur);
  const buf = ctx.createBuffer(1, frames, ctx.sampleRate);
  const data = buf.getChannelData(0);
  for (let i = 0; i < frames; i++) data[i] = Math.random() * 2 - 1;

  const src = ctx.createBufferSource();
  const filter = ctx.createBiquadFilter();
  const gain = ctx.createGain();

  src.buffer = buf;
  filter.type = 'lowpass';
  filter.frequency.setValueAtTime(freq, t);
  gain.gain.setValueAtTime(0.0001, t);
  gain.gain.exponentialRampToValueAtTime(vol, t + dur * 0.4);
  gain.gain.exponentialRampToValueAtTime(0.0001, t + dur);

  src.connect(filter).connect(gain).connect(ctx.destination);
  src.start(t);
}

const SOUNDS = {
  happy()    { blip(660, { vol: .06 }); blip(880, { delay: .09, vol: .06 }); },
  hello()    { blip(523, { vol: .05 }); blip(784, { delay: .12, dur: .18, vol: .05 }); },
  dance()    { [0, .25, .5, .75].forEach((d, i) =>
                 blip([523, 659, 784, 659][i], { delay: d, dur: .1, type: 'triangle', vol: .05 })); },
  surprise() { blip(400, { slide: 2.6, dur: .18, type: 'square', vol: .035 }); },
  dizzy()    { blip(700, { slide: .35, dur: .5, type: 'triangle', vol: .045 }); },
  yawn()     { breath({ dur: .7, freq: 700, vol: .05 }); blip(330, { slide: .7, dur: .6, vol: .025 }); },
  snore()    { breath({ dur: 1.1, freq: 340, vol: .04 }); },
  pickup()   { blip(880, { slide: 1.4, dur: .1, vol: .04 }); },
  drop()     { blip(300, { slide: .7, dur: .12, type: 'triangle', vol: .04 }); },
  step()     { blip(180, { dur: .05, type: 'triangle', vol: .015 }); },
  arrive()   { [523, 659, 784, 1047].forEach((f, i) =>
                 blip(f, { delay: i * .1, dur: .22, type: 'triangle', vol: .045 })); },
  giggle()   { [700, 640, 760, 680, 730].forEach((f, i) =>
                 blip(f, { delay: i * .085, dur: .07, type: 'triangle', vol: .04 })); },
  type()     { blip(1200, { dur: .025, type: 'square', vol: .012 }); },
  woof()     { blip(270, { dur: .1,  type: 'triangle', slide: .68, vol: .055 });
               blip(320, { delay: .17, dur: .13, type: 'triangle', slide: .58, vol: .055 }); },
  meow()     { blip(620, { dur: .17, type: 'triangle', slide: 1.35, vol: .05 });
               blip(840, { delay: .15, dur: .34, type: 'triangle', slide: .62, vol: .05 }); },
  poof()     { breath({ dur: .35, freq: 1800, vol: .06 }); },
  talk()     { blip(600, { dur: .06, type: 'triangle', vol: .03 });
               blip(700, { delay: .07, dur: .06, type: 'triangle', vol: .025 }); }
};

function play(name) {
  if (muted || !SOUNDS[name]) return;
  if (ctx.state === 'suspended') ctx.resume();
  SOUNDS[name]();
}

window.sfx = { play, setMuted };
