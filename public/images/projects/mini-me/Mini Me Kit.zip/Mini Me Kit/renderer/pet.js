// The pet's little brain: what they do, and how they react to you.

const svg    = document.getElementById('pet');
const bubble = document.getElementById('bubble');
const hearts = document.getElementById('hearts');

// --- the things they can do ------------------------------------------------

const REACTIONS = {
  happy:     { ms: 1100, sound: 'happy',    hearts: true,
               lines: ['hehe', 'hi!', ':D', 'that tickles', 'again!'] },
  wave:      { ms: 2100, sound: 'hello' },   // lines come from HELLOS
  dance:     { ms: 3600, sound: 'dance',
               lines: ['♪', 'this is my song', '♪ ♫'] },
  dance2:    { ms: 3600, sound: 'dance' },
  dance3:    { ms: 3600, sound: 'dance' },
  dance4:    { ms: 3600, sound: 'dance' },
  dance5:    { ms: 3600, sound: 'dance' },   // chicken
  dance6:    { ms: 3600, sound: 'dance' },   // snoopy
  dance7:    { ms: 3600, sound: 'dance' },   // sprinkler
  stretch:   { ms: 1600, sound: 'yawn',
               lines: ['nggh', 'stretch…'] },
  surprised: { ms: 900,  sound: 'surprise',
               lines: ['!', 'oh!', 'you scared me'] },
  dizzy:     { ms: 1300, sound: 'dizzy',
               lines: ['woah…', 'stop spinning me'] },
  sleep:     { ms: 0,    sound: 'snore',
               lines: ['zzz…'] }
};

// Lines come from the character file, so each one talks their own way.
// A line with a ~ in it is said in two parts, one after the other.
const IDLE_LINES = (svg.dataset.lines || 'hi!|nice work|break time?').split('|');
const HELLOS     = (svg.dataset.hellos || 'hello!|hi there').split('|');

// --- state ----------------------------------------------------------------

let state      = 'idle';   // idle | walk | drag | or any key of REACTIONS
let facing     = 1;        // 1 = right, -1 = left
let calm       = false;    // "calm mode": stays put and stays quiet
let cat        = false;    // grey cat form
let outfit     = '';       // which set of clothes is on
let intro      = false;    // true during the introduction
let walkTimer  = null;
let busyTimer  = null;
let lastTouch  = Date.now();
let clickBurst = 0;
let burstTimer = null;
let gigglTimer = null;
let awayFor    = 0;        // ms since your cursor last moved
let nearMe     = false;    // is the cursor hovering close by
let music      = false;    // is something playing
let danceTimer = null;     // keeps the dancing going while music plays

const MOVES = ['dance', 'dance2', 'dance3', 'dance4',
               'dance5', 'dance6', 'dance7'];

const ALL = ['idle', 'walk', 'drag', ...Object.keys(REACTIONS)];

function setState(next) {
  ALL.forEach(c => svg.classList.remove(c));
  state = next;
  svg.classList.add(next);
  svg.style.scale = `${facing} 1`;
}

function showLine(text, ms) {
  bubble.textContent = text;
  bubble.classList.remove('hidden');
  window.sfx.play('talk');
  clearTimeout(say._t);
  say._t = setTimeout(() => bubble.classList.add('hidden'), ms);
}

function say(text, ms = 2200) {
  if (calm) return;
  const parts = String(text).split('~');
  showLine(parts[0], parts[1] ? 1000 : ms);
  if (parts[1]) {
    clearTimeout(say._next);
    say._next = setTimeout(() => showLine(parts[1], ms), 1150);
  }
}

function pick(list) { return list[Math.floor(Math.random() * list.length)]; }

// Run one reaction, then settle back to standing around.
// In calm mode they still move, but without the noise, chatter or hearts.
function react(name) {
  const r = REACTIONS[name];
  if (!r) return;

  stopWalk();
  clearTimeout(busyTimer);
  setState(name);

  if (!calm) {
    window.sfx.play(r.sound);
    const lines = (name === 'wave') ? HELLOS : r.lines;
    if (lines) say(pick(lines), Math.max(1200, r.ms));

    if (r.hearts) {
      hearts.classList.remove('hidden');
      hearts.classList.add('show');
      setTimeout(() => {
        hearts.classList.remove('show');
        hearts.classList.add('hidden');
      }, r.ms);
    }
  }

  if (r.ms > 0) busyTimer = setTimeout(() => setState('idle'), r.ms);
}

// --- the introduction ------------------------------------------------------

const NAME    = svg.dataset.name || 'me';
const CRITTER = svg.dataset.critter || 'cat';   // what the onesie is

const HELLO_LINES = [
  `hola, I'm mini ${NAME}!`,
  svg.dataset.greeting || 'here to keep you company'
];

const wait = (ms) => new Promise(done => setTimeout(done, ms));

// Hold a pose for a moment, without the usual chatter.
function pose(name, ms) {
  clearTimeout(busyTimer);
  setState(name);
  busyTimer = setTimeout(() => setState('idle'), ms);
}

// Write a line into the bubble one letter at a time.
async function typeLine(text, speed) {
  bubble.textContent = '';
  bubble.classList.remove('hidden');
  for (let i = 0; i < text.length; i++) {
    bubble.textContent = text.slice(0, i + 1);
    if (i % 3 === 0 && !calm) window.sfx.play('type');
    await wait(speed);
  }
}

async function runIntro() {
  intro = true;
  document.body.classList.add('intro');
  bubble.classList.add('hidden');

  await wait(350);
  if (!calm) window.sfx.play('arrive');
  await wait(1000);

  pose('wave', 2100);
  if (!calm) window.sfx.play('hello');
  await wait(800);

  await typeLine(HELLO_LINES[0], 55);
  await wait(1100);
  await typeLine(HELLO_LINES[1], 38);
  await wait(2600);

  bubble.classList.add('hidden');
  document.body.classList.remove('intro');
  intro = false;
  window.pet.introDone();
  await wait(400);
  if (!calm) react('happy');
}

// --- outfits ---------------------------------------------------------------
// Every clothing part carries data-fit; only the chosen outfit's parts show.

// Read the wardrobe out of the drawing, so each character has their own.
const OUTFITS = [...new Set(
  [...document.querySelectorAll('.fit')].map(part => part.dataset.fit)
)];

function wear(name) {
  if (!OUTFITS.includes(name)) return;
  outfit = name;
  document.body.dataset.fit = name;
  document.querySelectorAll('.fit').forEach(part => {
    part.classList.toggle('on', part.dataset.fit === name);
  });
}

// --- dancing along to whatever is playing -----------------------------------
// One move at a time, swapped every few seconds, for as long as the music
// is on. No beeps: there is already music playing.

function danceOn() {
  if (danceTimer || calm) return;

  let last = '';
  const nextMove = () => {
    if (!music || calm) return danceOff();
    if (intro || state === 'drag' || state === 'sleep') return;   // let those finish

    let move = pick(MOVES);
    while (move === last && MOVES.length > 1) move = pick(MOVES);
    last = move;

    clearTimeout(busyTimer);
    setState(move);
    if (Math.random() < 0.18) say(pick(REACTIONS.dance.lines));
  };

  nextMove();
  danceTimer = setInterval(nextMove, 3800);
}

function danceOff() {
  clearInterval(danceTimer);
  danceTimer = null;
  if (MOVES.includes(state)) setState('idle');
}

// --- turning into a cat (and back) -----------------------------------------

function transform(on) {
  const next = (on === undefined) ? !cat : on;
  if (next === cat) return;
  cat = next;
  window.pet.setCat(cat);

  if (calm) {                       // no puff, no noise in calm mode
    document.body.classList.toggle('cat', cat);
    return;
  }

  window.sfx.play('poof');
  document.body.classList.add('poofing');

  setTimeout(() => {
    document.body.classList.toggle('cat', cat);
    if (cat) window.sfx.play(CRITTER === 'dog' ? 'woof' : 'meow');
  }, 280);

  setTimeout(() => document.body.classList.remove('poofing'), 600);
}

// --- walking --------------------------------------------------------------

function startWalk() {
  if (state !== 'idle' || nearMe) return;   // stays put while you are close
  facing = Math.random() < 0.5 ? -1 : 1;
  setState('walk');

  let steps = 0;
  const stopAt = Date.now() + 1500 + Math.random() * 3000;

  walkTimer = setInterval(() => {
    if (state !== 'walk') return stopWalk();
    window.pet.step(facing * 2);
    if (++steps % 22 === 0) window.sfx.play('step');
    if (Date.now() > stopAt) stopWalk();
  }, 16);
}

function stopWalk() {
  clearInterval(walkTimer);
  walkTimer = null;
  facing = 1;
  if (state === 'walk') setState('idle');
}

// --- small idle flourishes -------------------------------------------------

function blink() {
  svg.classList.add('blink');
  setTimeout(() => svg.classList.remove('blink'), 120);
}

function lookAt(x, y) {
  svg.style.setProperty('--gx', (x * 3.4).toFixed(2) + 'px');
  svg.style.setProperty('--gy', (y * 2.4).toFixed(2) + 'px');
}

// Only used when your cursor has been still for a while, so the eyes
// still have some life in them.
function glance() {
  lookAt(Math.random() < 0.5 ? -1 : 1, Math.random() * 0.5);
  setTimeout(() => lookAt(0, 0), 900 + Math.random() * 700);
}

(function blinkLoop() {
  setTimeout(() => { if (state !== 'sleep') blink(); blinkLoop(); },
             2600 + Math.random() * 5000);
})();

// --- the loop that decides what to do next ---------------------------------
// Most of the time the answer is "nothing" — the pet is meant to be easy to ignore.

const IDLE_CHOICES = [
  { weight: 12, run: startWalk },
  { weight:  4, run: () => react('dance') },
  { weight:  5, run: () => react('stretch') },
  { weight:  4, run: () => react('wave') },
  { weight:  5, run: () => say(pick(IDLE_LINES)) },
  { weight: 12, run: glance },
  { weight: 58, run: () => {} }            // just stand there
];

setInterval(() => {
  if (intro) return;
  if (calm) {
    if (state === 'idle' && Math.random() < 0.2) glance();
    return;
  }

  // Nods off once you have been away from the machine for three minutes.
  if (state === 'idle' && awayFor > 180000 && Date.now() - lastTouch > 180000) {
    return react('sleep');
  }

  // Music takes over from the idle loop entirely; see danceOn().
  if (music) return danceOn();
  if (state === 'sleep') { if (Math.random() < .12) window.sfx.play('snore'); return; }
  if (state !== 'idle') return;

  let roll = Math.random() * IDLE_CHOICES.reduce((n, c) => n + c.weight, 0);
  for (const choice of IDLE_CHOICES) {
    roll -= choice.weight;
    if (roll <= 0) return choice.run();
  }
}, 11000);

// --- your mouse ------------------------------------------------------------

let overPet  = false;
let dragging = false;
let downAt   = 0;

// Turn the window's click-catching on only while the cursor is on the drawing.
document.addEventListener('mousemove', (e) => {
  const el = document.elementFromPoint(e.clientX, e.clientY);
  const on = !!(el && el.closest('#pet'));
  if (on !== overPet) {
    overPet = on;
    window.pet.setInteractive(on);
  }
});

function wake() {
  const wasAsleep = state === 'sleep';
  lastTouch = Date.now();
  if (wasAsleep) react('surprised');
  return wasAsleep;
}

svg.addEventListener('mousedown', (e) => {
  if (e.button !== 0) return;              // right-click opens the menu instead
  if (wake()) return;
  downAt = Date.now();
  dragging = true;
  stopWalk();
  clearTimeout(busyTimer);
  setState('drag');
  window.pet.dragStart();

  if (!calm) {
    window.sfx.play('pickup');
    setTimeout(() => { if (dragging) window.sfx.play('giggle'); }, 320);
    clearInterval(gigglTimer);
    gigglTimer = setInterval(() => {
      if (!dragging) return clearInterval(gigglTimer);
      if (Math.random() < .7) window.sfx.play('giggle');
    }, 1500);
  }
});

window.addEventListener('mouseup', () => {
  if (!dragging) return;
  dragging = false;
  clearInterval(gigglTimer);
  window.pet.dragEnd();
  lastTouch = Date.now();

  const quick = Date.now() - downAt < 220;
  setState('idle');

  if (!quick) {
    if (!calm) window.sfx.play('drop');
    return;
  }

  // A quick click is a pat. Keep patting and they get giddy.
  clearTimeout(burstTimer);
  clickBurst++;
  burstTimer = setTimeout(() => { clickBurst = 0; }, 1400);

  if (clickBurst >= 7)       transform();
  else if (clickBurst >= 4)  react(pick(MOVES));
  else if (clickBurst === 3) react('wave');
  else                       react('happy');
});

// Right-click for the controls: hide, calm mode, size, sound, quit.
svg.addEventListener('contextmenu', (e) => {
  e.preventDefault();
  window.pet.menu();
});

// --- messages from the window ----------------------------------------------

window.pet.onEdge(() => { facing = -facing; svg.style.scale = `${facing} 1`; });
window.pet.onShaken(() => { lastTouch = Date.now(); react('dizzy'); });
window.pet.onMute((_e, on) => window.sfx.setMuted(on));
window.pet.onDo((_e, name) => {
  lastTouch = Date.now();
  react(name === 'dance' ? pick(MOVES) : name);
});

window.pet.onCursor((_e, c) => {
  awayFor = c.idleFor;
  nearMe  = c.near;

  // follow the pointer, unless it has been parked for a few seconds
  if (c.idleFor < 4000 && state !== 'sleep') lookAt(c.dx, c.dy);

  // you came back to the machine
  if (state === 'sleep' && c.idleFor < 400) {
    lastTouch = Date.now();
    react('stretch');
  }
});

// Said once, right after you switch "Dance to music" on.
const MUSIC_NOTES = {
  playing: '♪ ♫',
  paused:  'press play!',
  closed:  'put something on!',
  denied:  "can't hear spotify~allow it in settings"
};

window.pet.onMusicNote((_e, state) => {
  const note = MUSIC_NOTES[state];
  if (note) say(note, state === 'denied' ? 3600 : 2200);
});

// One beat, in seconds. Every dance animation is a multiple of this.
window.pet.onTempo((_e, beatsPerMinute) => {
  document.documentElement.style.setProperty('--beat', (60 / beatsPerMinute).toFixed(3) + 's');
});

window.pet.onMusic((_e, on) => {
  music = on;
  if (on) danceOn(); else danceOff();
});

window.pet.onCat((_e, on) => transform(on));
window.pet.onWear((_e, name) => { wear(name); if (!calm) window.sfx.play('happy'); });

window.pet.onCalm((_e, on) => {
  calm = on;
  document.body.classList.toggle('calm', on);
  if (on) {
    stopWalk();
    danceOff();
    clearTimeout(busyTimer);
    bubble.classList.add('hidden');
    if (state !== 'idle') setState('idle');
  }
});

window.pet.onIntro(() => runIntro());

wear(outfit || OUTFITS[0]);
setState('idle');
