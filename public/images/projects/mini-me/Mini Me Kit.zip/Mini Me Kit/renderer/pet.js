// The pet's little brain: what they do, and how they react to you.

const svg    = document.getElementById('pet');
const bubble = document.getElementById('bubble');
const hearts = document.getElementById('hearts');

// --- the things they can do ------------------------------------------------

const REACTIONS = {
  happy:     { ms: 1100, sound: 'happy',    hearts: true,
               lines: ['hehe', 'hi!', ':D', 'that tickles', 'again!'] },
  wave:      { ms: 2100, sound: 'hello',
               lines: ['hello!', 'hi there', 'hey you'] },
  dance:     { ms: 3600, sound: 'dance',
               lines: ['♪', 'this is my song', '♪ ♫'] },
  stretch:   { ms: 1600, sound: 'yawn',
               lines: ['nggh', 'stretch…'] },
  surprised: { ms: 900,  sound: 'surprise',
               lines: ['!', 'oh!', 'you scared me'] },
  dizzy:     { ms: 1300, sound: 'dizzy',
               lines: ['woah…', 'stop spinning me'] },
  sleep:     { ms: 0,    sound: 'snore',
               lines: ['zzz…'] }
};

const IDLE_LINES = [
  'hi!', 'nice work', 'break time?', 'i am here',
  'need water?', 'what are you making?', 'looking good', 'take a walk?'
];

// --- state ----------------------------------------------------------------

let state      = 'idle';   // idle | walk | drag | or any key of REACTIONS
let facing     = 1;        // 1 = right, -1 = left
let calm       = false;    // "calm mode": stays put and stays quiet
let cat        = false;    // grey cat form
let outfit     = '';       // which set of clothes is on
let intro      = false;    // true during the introduction
let walkTimer  = null;
let busyTimer  = null;
let lastTouch  = Date.now();
let clickBurst = 0;
let burstTimer = null;
let gigglTimer = null;

const ALL = ['idle', 'walk', 'drag', ...Object.keys(REACTIONS)];

function setState(next) {
  ALL.forEach(c => svg.classList.remove(c));
  state = next;
  svg.classList.add(next);
  svg.style.scale = `${facing} 1`;
}

function say(text, ms = 2200) {
  if (calm) return;
  bubble.textContent = text;
  bubble.classList.remove('hidden');
  window.sfx.play('talk');
  clearTimeout(say._t);
  say._t = setTimeout(() => bubble.classList.add('hidden'), ms);
}

function pick(list) { return list[Math.floor(Math.random() * list.length)]; }

// Run one reaction, then settle back to standing around.
// In calm mode they still move, but without the noise, chatter or hearts.
function react(name) {
  const r = REACTIONS[name];
  if (!r) return;

  stopWalk();
  clearTimeout(busyTimer);
  setState(name);

  if (!calm) {
    window.sfx.play(r.sound);
    if (r.lines) say(pick(r.lines), Math.max(1200, r.ms));

    if (r.hearts) {
      hearts.classList.remove('hidden');
      hearts.classList.add('show');
      setTimeout(() => {
        hearts.classList.remove('show');
        hearts.classList.add('hidden');
      }, r.ms);
    }
  }

  if (r.ms > 0) busyTimer = setTimeout(() => setState('idle'), r.ms);
}

// --- the introduction ------------------------------------------------------

const NAME    = svg.dataset.name || 'me';
const CRITTER = svg.dataset.critter || 'cat';   // what the onesie is

const HELLO_LINES = [
  `hola, I'm mini ${NAME}!`,
  svg.dataset.greeting || 'here to keep you company'
];

const wait = (ms) => new Promise(done => setTimeout(done, ms));

// Hold a pose for a moment, without the usual chatter.
function pose(name, ms) {
  clearTimeout(busyTimer);
  setState(name);
  busyTimer = setTimeout(() => setState('idle'), ms);
}

// Write a line into the bubble one letter at a time.
async function typeLine(text, speed) {
  bubble.textContent = '';
  bubble.classList.remove('hidden');
  for (let i = 0; i < text.length; i++) {
    bubble.textContent = text.slice(0, i + 1);
    if (i % 3 === 0 && !calm) window.sfx.play('type');
    await wait(speed);
  }
}

async function runIntro() {
  intro = true;
  document.body.classList.add('intro');
  bubble.classList.add('hidden');

  await wait(350);
  if (!calm) window.sfx.play('arrive');
  await wait(1000);

  pose('wave', 2100);
  if (!calm) window.sfx.play('hello');
  await wait(800);

  await typeLine(HELLO_LINES[0], 55);
  await wait(1100);
  await typeLine(HELLO_LINES[1], 38);
  await wait(2600);

  bubble.classList.add('hidden');
  document.body.classList.remove('intro');
  intro = false;
  window.pet.introDone();
  await wait(400);
  if (!calm) react('happy');
}

// --- outfits ---------------------------------------------------------------
// Every clothing part carries data-fit; only the chosen outfit's parts show.

// Read the wardrobe out of the drawing, so each character has their own.
const OUTFITS = [...new Set(
  [...document.querySelectorAll('.fit')].map(part => part.dataset.fit)
)];

function wear(name) {
  if (!OUTFITS.includes(name)) return;
  outfit = name;
  document.body.dataset.fit = name;
  document.querySelectorAll('.fit').forEach(part => {
    part.classList.toggle('on', part.dataset.fit === name);
  });
}

// --- turning into a cat (and back) -----------------------------------------

function transform(on) {
  const next = (on === undefined) ? !cat : on;
  if (next === cat) return;
  cat = next;
  window.pet.setCat(cat);

  if (calm) {                       // no puff, no noise in calm mode
    document.body.classList.toggle('cat', cat);
    return;
  }

  window.sfx.play('poof');
  document.body.classList.add('poofing');

  setTimeout(() => {
    document.body.classList.toggle('cat', cat);
    if (cat) window.sfx.play(CRITTER === 'dog' ? 'woof' : 'meow');
  }, 280);

  setTimeout(() => document.body.classList.remove('poofing'), 600);
}

// --- walking --------------------------------------------------------------

function startWalk() {
  if (state !== 'idle') return;
  facing = Math.random() < 0.5 ? -1 : 1;
  setState('walk');

  let steps = 0;
  const stopAt = Date.now() + 1500 + Math.random() * 3000;

  walkTimer = setInterval(() => {
    if (state !== 'walk') return stopWalk();
    window.pet.step(facing * 2);
    if (++steps % 22 === 0) window.sfx.play('step');
    if (Date.now() > stopAt) stopWalk();
  }, 16);
}

function stopWalk() {
  clearInterval(walkTimer);
  walkTimer = null;
  facing = 1;
  if (state === 'walk') setState('idle');
}

// --- small idle flourishes -------------------------------------------------

function blink() {
  svg.classList.add('blink');
  setTimeout(() => svg.classList.remove('blink'), 120);
}

function glance() {
  const side = Math.random() < 0.5 ? 'lookL' : 'lookR';
  svg.classList.add(side);
  setTimeout(() => svg.classList.remove(side), 900 + Math.random() * 700);
}

(function blinkLoop() {
  setTimeout(() => { if (state !== 'sleep') blink(); blinkLoop(); },
             2600 + Math.random() * 5000);
})();

// --- the loop that decides what to do next ---------------------------------
// Most of the time the answer is "nothing" — the pet is meant to be easy to ignore.

const IDLE_CHOICES = [
  { weight: 12, run: startWalk },
  { weight:  4, run: () => react('dance') },
  { weight:  5, run: () => react('stretch') },
  { weight:  4, run: () => react('wave') },
  { weight:  5, run: () => say(pick(IDLE_LINES)) },
  { weight: 12, run: glance },
  { weight: 58, run: () => {} }            // just stand there
];

setInterval(() => {
  if (intro) return;
  if (calm) {
    if (state === 'idle' && Math.random() < 0.2) glance();
    return;
  }

  // Nods off after three quiet minutes.
  if (state === 'idle' && Date.now() - lastTouch > 180000) return react('sleep');
  if (state === 'sleep') { if (Math.random() < .12) window.sfx.play('snore'); return; }
  if (state !== 'idle') return;

  let roll = Math.random() * IDLE_CHOICES.reduce((n, c) => n + c.weight, 0);
  for (const choice of IDLE_CHOICES) {
    roll -= choice.weight;
    if (roll <= 0) return choice.run();
  }
}, 11000);

// --- your mouse ------------------------------------------------------------

let overPet  = false;
let dragging = false;
let downAt   = 0;

// Turn the window's click-catching on only while the cursor is on the drawing.
document.addEventListener('mousemove', (e) => {
  const el = document.elementFromPoint(e.clientX, e.clientY);
  const on = !!(el && el.closest('#pet'));
  if (on !== overPet) {
    overPet = on;
    window.pet.setInteractive(on);
  }
});

function wake() {
  const wasAsleep = state === 'sleep';
  lastTouch = Date.now();
  if (wasAsleep) react('surprised');
  return wasAsleep;
}

svg.addEventListener('mousedown', (e) => {
  if (e.button !== 0) return;              // right-click opens the menu instead
  if (wake()) return;
  downAt = Date.now();
  dragging = true;
  stopWalk();
  clearTimeout(busyTimer);
  setState('drag');
  window.pet.dragStart();

  if (!calm) {
    window.sfx.play('pickup');
    setTimeout(() => { if (dragging) window.sfx.play('giggle'); }, 320);
    clearInterval(gigglTimer);
    gigglTimer = setInterval(() => {
      if (!dragging) return clearInterval(gigglTimer);
      if (Math.random() < .7) window.sfx.play('giggle');
    }, 1500);
  }
});

window.addEventListener('mouseup', () => {
  if (!dragging) return;
  dragging = false;
  clearInterval(gigglTimer);
  window.pet.dragEnd();
  lastTouch = Date.now();

  const quick = Date.now() - downAt < 220;
  setState('idle');

  if (!quick) {
    if (!calm) window.sfx.play('drop');
    return;
  }

  // A quick click is a pat. Keep patting and they get giddy.
  clearTimeout(burstTimer);
  clickBurst++;
  burstTimer = setTimeout(() => { clickBurst = 0; }, 1400);

  if (clickBurst >= 7)       transform();
  else if (clickBurst >= 4)  react('dance');
  else if (clickBurst === 3) react('wave');
  else                       react('happy');
});

// Right-click for the controls: hide, calm mode, size, sound, quit.
svg.addEventListener('contextmenu', (e) => {
  e.preventDefault();
  window.pet.menu();
});

// --- messages from the window ----------------------------------------------

window.pet.onEdge(() => { facing = -facing; svg.style.scale = `${facing} 1`; });
window.pet.onShaken(() => { lastTouch = Date.now(); react('dizzy'); });
window.pet.onMute((_e, on) => window.sfx.setMuted(on));
window.pet.onDo((_e, name) => { lastTouch = Date.now(); react(name); });

window.pet.onCat((_e, on) => transform(on));
window.pet.onWear((_e, name) => { wear(name); if (!calm) window.sfx.play('happy'); });

window.pet.onCalm((_e, on) => {
  calm = on;
  document.body.classList.toggle('calm', on);
  if (on) {
    stopWalk();
    clearTimeout(busyTimer);
    bubble.classList.add('hidden');
    if (state !== 'idle') setState('idle');
  }
});

window.pet.onIntro(() => runIntro());

wear(outfit || OUTFITS[0]);
setState('idle');
