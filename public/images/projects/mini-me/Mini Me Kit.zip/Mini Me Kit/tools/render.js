// Draw the character to a PNG so you can SEE what you changed.
//
//   npm run look                  every outfit, side by side
//   npm run look -- --pose drag   every outfit in a pose
//   npm run look -- --who you     a specific character
//   npm run look -- --animal      the animal onesie
//
// Poses: idle drag happy dance wave surprised sleep stretch walk
// The picture lands in preview.png.

const { app, BrowserWindow } = require('electron');
const fs = require('fs');
const path = require('path');

const ROOT = path.join(__dirname, '..');
const RENDERER = path.join(ROOT, 'renderer');
const TMP = path.join(ROOT, '.preview.html');

// --- what to draw -----------------------------------------------------------

const argv = process.argv.slice(2);
const flag = (name, fallback) => {
  const i = argv.indexOf('--' + name);
  return i === -1 ? fallback : (argv[i + 1] || fallback);
};

const pose   = flag('pose', '');
const animal = argv.includes('--animal');
const only   = flag('who', '');

const characters = fs.readdirSync(RENDERER)
  .filter(f => f.endsWith('.html'))
  .map(f => f.replace('.html', ''))
  .filter(who => !only || who === only);

if (!characters.length) {
  console.error(`No character files found in renderer/. Expected e.g. you.html`);
  process.exit(1);
}

// --- build one page holding every panel -------------------------------------

const css = fs.readFileSync(path.join(RENDERER, 'style.css'), 'utf8');
let panels = '';

for (const who of characters) {
  const file = fs.readFileSync(path.join(RENDERER, who + '.html'), 'utf8');
  const svg = (file.match(/<svg id="pet"[\s\S]*?<\/svg>/) || [])[0];
  if (!svg) { console.error(`${who}.html has no <svg id="pet">`); process.exit(1); }

  const bodyClass = (file.match(/<body class="([^"]*)"/) || [, ''])[1];
  const fits = [...new Set([...svg.matchAll(/data-fit="([^"]+)"/g)].map(m => m[1]))]
    .filter(id => /^[\w-]+$/.test(id));
  const shots = animal ? [['(animal)', null]] : fits.map(f => [f, f]);

  for (const [label, fit] of shots) {
    const tagged = svg.replace('<svg id="pet"', `<svg id="pet" class="${pose}"`);
    panels += `<div class="panel ${bodyClass} ${animal ? 'suit' : ''}" data-fit="${fit || ''}">
        <div class="cap">${who} — ${label}${pose ? ' — ' + pose : ''}</div>
        <div class="frame"><div id="stage">${tagged}</div></div>
      </div>`;
  }
}

const page = `<!doctype html><html><head><meta charset="utf-8"><style>
${css}
body { background:#e9e6e0; margin:0; display:flex; flex-wrap:wrap; gap:10px; padding:10px;
       align-items:flex-start; }
.cap { font:10px/1 -apple-system, system-ui, sans-serif; color:#8a8378; text-transform:uppercase;
       letter-spacing:.05em; margin-bottom:4px; }
/* the real window, outlined, so you can see anything falling outside it */
.frame { width:170px; height:233px; outline:1px solid #d7cfc2; overflow:hidden; position:relative; }
.frame #stage { height:100%; }
.frame svg { width:100% !important; height:100% !important; }
.panel.suit .onesie { display:block; }
.panel.suit .fit { display:none !important; }
.panel.suit #cathat, .panel.suit #tail { display:block; }
/* freeze mid-animation so poses are visible in a still image */
.frame * { animation-play-state:paused !important; animation-delay:-.28s !important; }
</style></head><body>${panels}
<script>
document.querySelectorAll('.panel').forEach(p => {
  const want = p.dataset.fit;
  p.querySelectorAll('.fit').forEach(f => f.classList.toggle('on', f.dataset.fit === want));
});
</script></body></html>`;

fs.writeFileSync(TMP, page);

// --- take the picture -------------------------------------------------------

const COLS = Math.min(6, Math.max(1, (page.match(/class="panel/g) || []).length));
const width = Math.min(1300, 20 + COLS * 182);
const rows = Math.ceil((page.match(/class="panel/g) || []).length / COLS);
const height = 20 + rows * 252;

app.whenReady().then(async () => {
  const win = new BrowserWindow({ width, height, show: false, useContentSize: true,
                                 backgroundColor: '#e9e6e0' });
  await win.loadFile(TMP);
  await new Promise(r => setTimeout(r, 700));
  const out = path.join(ROOT, 'preview.png');
  fs.writeFileSync(out, (await win.capturePage()).toPNG());
  fs.unlinkSync(TMP);
  console.log('wrote ' + out);
  app.quit();
});
